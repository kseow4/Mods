version https://git-lfs.github.com/spec/v1
oid sha256:b5ff095d2cc9cbdfbc903f837e281f44669b3804c6250c2fdebf33e27474cf6a
size 1576
