version https://git-lfs.github.com/spec/v1
oid sha256:17d1a5ddf0252e15acb7a06ca0b5c5e53303b34eaf27c5cc0c16b7a71f2c628f
size 3542
