version https://git-lfs.github.com/spec/v1
oid sha256:1744effb0164dda6e3de1332c54b9a2c3747f8ffd0be0a6c1af13bf622ed2d92
size 1110
