version https://git-lfs.github.com/spec/v1
oid sha256:6af4ef4b23c968833f0377e88f277b8dd16834fe9345e406580055e5be9b6f78
size 2603
