version https://git-lfs.github.com/spec/v1
oid sha256:aa81b7e767b46da6b312a5b45dc2a731842e2fb1058b95979504b3f85d3e12d2
size 3446
