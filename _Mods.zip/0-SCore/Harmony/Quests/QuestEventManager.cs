version https://git-lfs.github.com/spec/v1
oid sha256:27757bfd68ea22197468c8be825c28816b6e6e8411a96a916dcce31b67b9b8f4
size 819
