version https://git-lfs.github.com/spec/v1
oid sha256:52b4254789dfc9602142775ee46779dfe0a3c242f3fb2d6a5d0194b8560b1eaa
size 1356
