version https://git-lfs.github.com/spec/v1
oid sha256:9cf24cbb96b47697698ebf4ec6e12de1299ef8073a4514808834775e6bb9acf0
size 4870
