version https://git-lfs.github.com/spec/v1
oid sha256:f4600692fa6d51990692f4f379094c45aa6981ea27feda9a277b084ecef622a0
size 808
