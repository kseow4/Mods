version https://git-lfs.github.com/spec/v1
oid sha256:4c8e7dec24a0685c503c2274a336dd61ab3abe9ca0b4a499db08464f176efff1
size 6156
