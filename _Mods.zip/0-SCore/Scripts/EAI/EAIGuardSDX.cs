version https://git-lfs.github.com/spec/v1
oid sha256:7f9da69a853ea42f81420a113abbf71e85894c7870db30b97fc58fcc241e3e5c
size 3105
