version https://git-lfs.github.com/spec/v1
oid sha256:c1af6686a18c2aec1b27c4de4b7692f8e243fd8ac8084085d85cc64b6ed607f7
size 1167
