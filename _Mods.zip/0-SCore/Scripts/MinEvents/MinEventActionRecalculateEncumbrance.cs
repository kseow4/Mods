version https://git-lfs.github.com/spec/v1
oid sha256:92cfa244953ce0ca86604be0657d0c0ca42a315caeea03139316a5e7731a8a9c
size 423
