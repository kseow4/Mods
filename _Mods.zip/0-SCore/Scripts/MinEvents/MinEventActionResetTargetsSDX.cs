version https://git-lfs.github.com/spec/v1
oid sha256:3280071f628ccc63d420e71f37ddaf8c150d5d327e96c7ed33314d339c0eeb3a
size 427
