version https://git-lfs.github.com/spec/v1
oid sha256:c77a053c0a170933e79dd89cb05aba74c6d96b6bc31d2aa6010e75b463a1a3c8
size 3378
