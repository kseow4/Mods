version https://git-lfs.github.com/spec/v1
oid sha256:852ea1f42540c64842417445d35acf9cbed186d7a672cc613a1995c38e9ae3fc
size 1340
